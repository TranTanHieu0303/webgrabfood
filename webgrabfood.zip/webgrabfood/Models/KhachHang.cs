﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webgrabfood.Models
{
    public class KhachHang
    {
        public string idKH { get; set; }
        public string SDT { get; set; }
        public string TenKH { get; set; }
        public string TinhThanh { get; set; }
        public string PhuongXa { get; set; }
        public string QuanHuyen { get; set; }
        public string SonhaTenDuong { get; set; }
        public string Gmail { get; set; }
        public string Password { get; set; }
        public string Gioitinh { get; set; }


    }
}