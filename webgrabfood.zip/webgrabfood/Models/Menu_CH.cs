﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webgrabfood.Models
{
    public class Menu_CH
    {
        public string idLoai { get; set; }
        public string mName { get; set; }
    }
}