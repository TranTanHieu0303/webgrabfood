﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webgrabfood.Models
{
    public class DanhMuc
    {
        public string IDDanhmuc { get; set; }
        public string mImage { get; set; }
        public string mName { get; set; }
    }
}