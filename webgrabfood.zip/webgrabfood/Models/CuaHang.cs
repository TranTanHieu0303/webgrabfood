﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webgrabfood.Models
{
    public class CuaHang
    {
        public string idCH { get; set; }
        public string idDM { get; set; }
        public string SDT { get; set; }
        public string Gmail { get; set; }
        public string TenCH { get; set; }
        public string TinhThanh { get; set; }
        public string PhuongXa { get; set; }
        public string QuanHuyen { get; set; }
        public string SonhaTenDuong { get; set; }
        public string Password { get; set; }
        public string HinhAnh { get; set; }
        public string MoTa { get; set; }
    }
}