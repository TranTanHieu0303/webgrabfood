﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webgrabfood.Models
{
    public class ChitietHD
    {
        public string idHD { get; set; }
        public string idSP { get; set; }
        public int GiaBan { get; set; }
        public int TongTien { get; set; }
        public int SoLuong { get; set; }
    }
}